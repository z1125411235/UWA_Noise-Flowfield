# Noise Flowfield
Demo project for Unity

Flowing in the noise field about 500 cubes. The colors modified by audio spectrum.

![Demo](docs/demo.gif)
